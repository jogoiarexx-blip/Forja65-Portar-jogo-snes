@echo off
cd /d "%~dp0"
start "" "Forja65-Portable.html"
